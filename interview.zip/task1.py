import csv, pandas as pd
from pandas.io.parsers import read_csv

ordersDict = {}

with open('orders.csv') as csvfile:
    reader = csv.DictReader(csvfile)
    for row in reader:
        
orders = pd.read_csv("orders.csv")
products = pd.read_csv("products.csv")
# print(orders)
